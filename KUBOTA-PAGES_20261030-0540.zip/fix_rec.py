# -*- coding: utf-8 -*-
"""แก้ไขหน้าแนะนำ (all-recommend) + ส่วนแนะนำในหน้าแรก ให้ตรงกับ แนะนำ.txt"""
import os, re, io

BASE = os.path.dirname(os.path.abspath(__file__))
REC  = os.path.join(BASE, 'web-updated/site/all-recommend/index.html')
HOME = os.path.join(BASE, 'web-updated/site/index.html')
IMGD = os.path.join(BASE, 'web-updated/site/used/rec')

# ---- ข้อมูลจาก work-img/แนะนำ/แนะนำ.txt (หัวข้อ 1-8) ----
# ดาวน์ = ตัวเลขเดียวใน txt (ฟรีดาวน์ / 0 = ฟรีดาวน์)
# เงินสด = None เมื่อ txt ไม่ได้ระบุราคา
V = {
 1: dict(model='M108S-B',      chip='+ใบมีด+ผาน 1 ตัว',     year='2568', hrs='800 ชม.',
         down='ฟรีดาวน์', cash='1,090,000.-', link='/site/used-tractors/u6-m108s/'),
 2: dict(model='M8808',        chip='+อุปกรณ์ 2 ชิ้น',      year='2565', hrs='994 ชม.',
         down='50,000 บาท',  cash='8xx,xxx.-',   link=None),
 3: dict(model='M7040-B',      chip='+ใบมีด+ผาน 1 ตัว',     year='2566', hrs='1,100 ชม.',
         down='55,000 บาท',  cash='715,000.-',   link='/site/used-tractors/m7040-b/'),
 4: dict(model='MU4902-B',     chip='+ใบมีด+ผานใหม่ 1 ตัว', year='2565', hrs='ไมค์ชำรุด',
         down='ฟรีดาวน์', cash='560,000.-',   link='/site/used-tractors/mu4902-b/'),
 5: dict(model='L5018SP',      chip='+บุ้งกี๋มาตรฐาน',      year='2566', hrs='769 ชม.',
         down='20,000 บาท',  cash=None,          link='/site/used-tractors/l5018sp/'),
 6: dict(model='M6240SUH-B',   chip='+ใบมีด+ผาน 1 ตัว',     year='2567', hrs='1,398 ชม.',
         down='35,000 บาท',  cash='655,000.-',   link='/site/used-tractors/m6240suh-b/'),
 7: dict(model='MU5702-B',     chip='+ใบมีด+ผาน 1 ตัว',     year='2567', hrs='1,643 ชม.',
         down='25,000 บาท',  cash=None,          link='/site/used-tractors/mu5702-b/'),
 8: dict(model='M7508 (W)',    chip='+ใบมีด+ผาน 1 ตัว',     year='2568', hrs='628 ชม.',
         down='140,000 บาท', cash=None,
         extra=('ดาวน์+ผ่อนรายปี', '140,000 + 16X,687×1 + 3,000×11'),
         link='/site/used-tractors/m7508/'),
}

def images(n):
    """รายชื่อรูป na{n}-*.jpg เรียงลำดับ"""
    pat = re.compile(r'^na%d-(\d+)\.jpg$' % n)
    out = []
    for f in os.listdir(IMGD):
        m = pat.match(f)
        if m:
            out.append((int(m.group(1)), f))
    return [f for _, f in sorted(out)]

def gallery(n):
    """data-gallery attribute สำหรับคันที่ n (รูปสุดท้าย = เซลล์ประจำคัน ถ้ามี)"""
    fs = images(n)
    if not fs:
        return ''
    parts = []
    for i, f in enumerate(fs, 1):
        name = '%s · เซลล์ประจำคัน' % V[n]['model'] if i == len(fs) else '%s · ภาพ %d' % (V[n]['model'], i)
        parts.append('{"src": "/site/used/rec/%s", "name": "%s"}' % (f, name))
    return " data-gallery='[%s]'" % ', '.join(parts)

def facts(n):
    """เนื้อหาใน <div class="sr-facts"> ตามโครงเดิม"""
    v = V[n]
    rows = [
        ('ปีรถ (พ.ศ.)', v['year']),
        ('ชั่วโมง',      v['hrs']),
        ('วางดาวน์',    v['down']),
        ('ออกรถ',        v['down']),
    ]
    if v.get('cash'):
        rows.append(('ราคาเงินสด', v['cash']))
    elif v.get('extra'):
        rows.append(v['extra'])
    out = ['<div class="sr-facts">']
    for k, val in rows:
        cls = 'sr-fact sr-cash' if k == 'ราคาเงินสด' else 'sr-fact'
        out.append('<div class="%s"><span class="k">%s</span><span class="v">%s</span></div>'
                   % (cls, k, val))
    out.append('</div>')
    return ''.join(out)


def fix_articles(html, cls='sr-card-h'):
    """แก้ทุก <article> ตามลำดับที่เจอ: รูป hero, data-gallery, sr-facts"""
    pat = re.compile(r'(<article class="%s".*?</article>)' % re.escape(cls), re.S)
    counter = {'n': 0}

    def repl(m):
        counter['n'] += 1
        n = counter['n']
        a = m.group(1)
        if n not in V:
            return a
        fs = images(n)
        # 1) hero img
        a = re.sub(r'(<img src=")/site/used/rec/na\d+-\d+\.jpg(")',
                   lambda mm: mm.group(1) + '/site/used/rec/%s' % fs[0] + mm.group(2), a, count=1)
        # 2) data-gallery -> แทนที่ของเดิม หรือแทรกถ้ายังไม่มี
        gal = gallery(n)
        if 'data-gallery=' in a:
            a = re.sub(r" data-gallery='[^']*'", gal, a, count=1)
            a = re.sub(r' data-gallery="[^"]*"', gal, a, count=1)
        else:
            a = a.replace('<div class="sr-card-img', '<div class="sr-card-img', 1)
            # แทรกหลัง attribute ตัวแรกของ .sr-card-img
            a = re.sub(r'(<div class="sr-card-img[^>]*?)( role=|>)',
                       lambda mm: mm.group(1) + gal + mm.group(2), a, count=1)
        # 3) sr-facts
        a = re.sub(r'<div class="sr-facts">.*?</div>\s*(?=<a class="sr-detail")',
                   facts(n) + '\n\n', a, count=1, flags=re.S)
        return a

    return pat.sub(repl, html)


def main():
    # ---------- หน้า all-recommend ----------
    h = io.open(REC, encoding='utf-8').read()
    before = h
    h = fix_articles(h)
    # ป้าย "(จากโพสต์)" ที่เหลือ
    h = h.replace('ราคาเงินสด (จากโพสต์)', 'ราคาเงินสด')
    # 0 บาท -> ฟรีดาวน์ (เฉพาะช่องวางดาวน์/ออกรถ)
    h = re.sub(r'(<span class="k">(?:วางดาวน์|ออกรถ)</span><span class="v">)0 บาท',
               r'\g<1>ฟรีดาวน์', h)
    io.open(REC, 'w', encoding='utf-8').write(h)
    print('[all-recommend] เขียนแล้ว', len(before), '->', len(h))

    # ---------- ส่วนแนะนำในหน้าแรก ----------
    h = io.open(HOME, encoding='utf-8').read()
    before = h
    h = fix_articles(h)
    h = h.replace('ราคาเงินสด (จากโพสต์)', 'ราคาเงินสด')
    h = re.sub(r'(<span class="k">(?:วางดาวน์|ออกรถ)</span><span class="v">)0 บาท',
               r'\g<1>ฟรีดาวน์', h)
    io.open(HOME, 'w', encoding='utf-8').write(h)
    print('[index]        เขียนแล้ว', len(before), '->', len(h))

    # ---------- รายงาน ----------
    for path in (REC, HOME):
        h = io.open(path, encoding='utf-8').read()
        print('\n==', os.path.basename(os.path.dirname(path)) or 'index', '==')
        for kw in ('รอข้อมูล', '(จากโพสต์)', 'ฟรีดาวน์', 'data-gallery'):
            print('   %-16s %d' % (kw, h.count(kw)))
        arts = re.findall(r'<article class="sr-card-h".*?</article>', h, re.S)
        print('   จำนวนการ์ด:', len(arts))


if __name__ == '__main__':
    main()
