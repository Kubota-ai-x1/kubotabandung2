import Link from 'next/link';
import { notFound } from 'next/navigation';
import ProductModelList from './ProductModelList';
import { combineSeriesList, getCombineSeriesBySlug } from '../../../../lib/combineProducts';
import { tractorSeries } from '../../../../lib/tractorProducts';

export function generateStaticParams() {
  return [
    ...Object.keys(tractorSeries).map((series) => ({
      slug: 'tractors',
      series,
    })),
    ...combineSeriesList.map(({ slug, series }) => ({ slug, series })),
  ];
}

export default async function TractorSeriesPage({ params }) {
  const { slug, series } = await params;
  const combineFamily = slug === 'harvesters' ? getCombineSeriesBySlug(series) : null;
  const productFamily = slug === 'tractors' ? tractorSeries[series] : null;

  if (combineFamily) {
    return (
      <main className="product-category-page tractor-series-page">
        <div className="product-breadcrumbs-wrap">
          <div className="product-breadcrumbs">
            <Link href="/">หน้าแรก</Link>
            <span aria-hidden="true" className="breadcrumb-separator">/</span>
            <Link href="/products">สินค้าใหม่มือหนึ่ง</Link>
            <span aria-hidden="true" className="breadcrumb-separator">/</span>
            <Link href="/products/harvesters">รถเกี่ยว</Link>
            <span aria-hidden="true" className="breadcrumb-separator">/</span>
            <span>{combineFamily.name}</span>
          </div>
        </div>

        <section className="tractor-feature-hero category-placeholder-hero combine-series-hero">
          <span className="category-placeholder-mark" aria-hidden="true">
            {combineFamily.series.replace('-hp', ' HP').toUpperCase()}
          </span>
          <div className="tractor-hero-copy">
            <p className="eyebrow">KUBOTA HARVESTERS · SERIES OVERVIEW</p>
            <h1>{combineFamily.name}</h1>
            <p>{combineFamily.tagline}</p>
          </div>
          <span className="hero-image-caption">รอภาพถ่ายรถเกี่ยวจริงจากทีมงาน</span>
        </section>

        <header className="product-page-header">
          <p className="eyebrow">รายละเอียดกลุ่มรถเกี่ยว</p>
          <h2>จุดเด่นของกลุ่มนี้</h2>
          <p className="product-page-description">{combineFamily.tagline}</p>
        </header>

        <section className="combine-family-details" aria-label={`จุดเด่น ${combineFamily.name}`}>
          <ul className="combine-series-features">
            {combineFamily.features.map((feature) => (
              <li key={feature}>{feature}</li>
            ))}
          </ul>
          <p className="combine-family-price">
            <span>ราคาเริ่มต้น</span>
            <strong>{new Intl.NumberFormat('th-TH').format(combineFamily.startingPrice)} บาท</strong>
            <small>โปรดสอบถามทีมงานเพื่อยืนยันราคาและรายละเอียดก่อนตัดสินใจ</small>
          </p>
        </section>

        <section className="category-awaiting" aria-label="ข้อมูลรุ่นย่อย">
          <div className="category-awaiting-card">
            <h2>รุ่นย่อยในกลุ่มนี้</h2>
            <p className="showroom-prep-lead">
              รายชื่อรุ่นย่อยและรายละเอียดสินค้าแยกตามรุ่นกำลังรอข้อมูลยืนยัน
              หน้านี้จะแสดงรุ่นที่ตรวจสอบแล้วเมื่อได้รับข้อมูลและภาพจริงจากทีมงาน
            </p>
            <div className="showroom-prep-actions">
              <Link className="ghost-button" href="/products/harvesters">
                กลับไปเลือกกลุ่มรถเกี่ยว
              </Link>
              <a
                className="solid-button"
                href="https://line.me/R/ti/p/@kubotabandung"
                target="_blank"
                rel="noreferrer"
              >
                สอบถามกลุ่มนี้ทาง LINE <span aria-hidden="true">↗</span>
              </a>
            </div>
          </div>
        </section>
      </main>
    );
  }

  if (!productFamily) notFound();

  return (
    <main className="product-category-page tractor-series-page">
      <div className="product-breadcrumbs-wrap">
        <div className="product-breadcrumbs">
          <Link href="/">หน้าแรก</Link>
          <span aria-hidden="true" className="breadcrumb-separator">/</span>
          <Link href="/products">สินค้าใหม่มือหนึ่ง</Link>
          <span aria-hidden="true" className="breadcrumb-separator">/</span>
          <Link href="/products/tractors">รถไถ</Link>
          <span aria-hidden="true" className="breadcrumb-separator">/</span>
          <span>{productFamily.label}</span>
        </div>
      </div>

      <figure className="tractor-series-hero" aria-label="ภาพแบนเนอร์รถแทรกเตอร์คูโบต้า">
        <img
          src="/images/kubota-l-series-hero.jpg"
          alt="แทรกเตอร์คูโบต้าสีส้มบนแบนเนอร์ประชาสัมพันธ์"
        />
      </figure>

      <header className="product-page-header">
        <p className="eyebrow">SERIES OVERVIEW · {productFamily.power}</p>
        <h1>แทรกเตอร์{productFamily.label}</h1>
        <p className="product-page-description">
          กลุ่มแทรกเตอร์กำลังเครื่องยนต์ {productFamily.power} — คัดสรรรุ่นย่อยและออปชันที่พร้อมส่งมอบ 
          เลือกรุ่นที่ต้องการเพื่อสอบถามราคาโปรโมชั่นล่าสุดและสิทธิพิเศษจาก คูโบต้า บ้านดุง
        </p>
        <p className="product-image-note">
          * ราคาและรายการอุปกรณ์เป็นราคาแนะนำสำหรับการอ้างอิง โปรดสอบถามทีมงานเพื่อยืนยันข้อเสนอและแคมเปญประจำเดือน
        </p>
      </header>

      {productFamily.products.length > 0 ? (
        <>
          <ProductModelList products={productFamily.products} series={series} />
          <section className="product-page-cta" id="product-contact">
            <div className="product-cta-copy">
              <p className="eyebrow">KUBOTA BAN DUNG SPECIAL OFFERS</p>
              <h2>สนใจแทรกเตอร์{productFamily.label}?</h2>
              <p>ปรึกษาเรื่องเงินดาวน์ อัตราผ่อนชำระ หรือโปรโมชั่นของแถมล่าสุดกับผู้แทนจำหน่าย คูโบต้า บ้านดุง</p>
            </div>
            <div className="product-page-actions">
              <Link href="/products/tractors" className="ghost-button">
                กลับไปเลือกรุ่นอื่น <span aria-hidden="true">↗</span>
              </Link>
              <a
                href="https://line.me/R/ti/p/@kubotabandung"
                target="_blank"
                rel="noreferrer"
                className="solid-button"
              >
                คุยกับทีมงานทาง LINE <span aria-hidden="true">↗</span>
              </a>
            </div>
          </section>
        </>
      ) : (
        <section className="product-category-note">
          <p>ข้อมูลรายการรุ่นของตระกูลนี้ยังอยู่ระหว่างรวบรวมจากแหล่งข้อมูลที่ยืนยันได้</p>
        </section>
      )}
    </main>
  );
}
