# -*- coding: utf-8 -*-
"""2) การ์ดเซลล์แบบบาง — ป้าย + เบอร์เป็นข้อความธรรมดา (ลาก copy ได้ ไม่ใช่ปุ่มโทร)
   ใช้: python fix_step2.py [--apply]"""
import io, re, sys, glob

APPLY = '--apply' in sys.argv
PHONE_OVERRIDE = {          # 8 คันจาก work-img/แนะนำ/แนะนำ.txt
    'u6-m108s': '098-2057355', 'm7040-b': '098-2057355',
    'mu4902-b': '098-2057355', 'l5018sp': '098-1039700',
    'm6240suh-b': '0610218998', 'mu5702-b': '098-8264663',
    'm7508': '0610180483', 'm8808': '098-1039700',
}

# การ์ดใหม่ (HTML)
def new_html(phone):
    return ('<section class="sd-sellercard sd-sellercard-slim" '
            'aria-label="เบอร์เซลล์ประจำคัน">'
            '<span class="sd-sellercard-role">เซลล์ประจำคันนี้</span>'
            '<span class="sd-sellercard-phone">%s</span></section>' % phone)

# การ์ดใหม่ (RSC payload) — หนี backslash ให้ตรงรูปแบบไฟล์
def new_json(phone, esc):
    q = esc                       # เช่น '\\"'
    return ('[' + q + '$' + q + ',' + q + 'section' + q + ',null,{'
            + q + 'className' + q + ':' + q + 'sd-sellercard sd-sellercard-slim' + q + ','
            + q + 'aria-label' + q + ':' + q + 'เบอร์เซลล์ประจำคัน' + q + ','
            + q + 'children' + q + ':[[[' + q + '$' + q + ',' + q + 'span' + q + ',null,{'
            + q + 'className' + q + ':' + q + 'sd-sellercard-role' + q + ','
            + q + 'children' + q + ':' + q + 'เซลล์ประจำคันนี้' + q + '}],'
            + '[' + q + '$' + q + ',' + q + 'span' + q + ',null,{'
            + q + 'className' + q + ':' + q + 'sd-sellercard-phone' + q + ','
            + q + 'children' + q + ':' + q + phone + q + '}]]]}]')

OLD_HTML = re.compile(
    r'<section class="sd-sellercard".*?</section>', re.S)

rows = []
done = 0
for p in sorted(glob.glob('web-updated/site/used-tractors/*/index.html')):
    slug = p.replace('\\', '/').split('used-tractors/')[1].split('/')[0]
    h0 = io.open(p, encoding='utf-8').read()
    h = h0
    m = OLD_HTML.search(h)
    phone = PHONE_OVERRIDE.get(slug)
    if m:                                  # มีอยู่แล้ว -> แทนที่ (เก็บเบอร์เดิมถ้าไม่ override)
        old = m.group(0)
        cur = re.search(r'tel:([0-9+-]+)', old)
        if phone is None and cur:
            phone = cur.group(1)
        phone = phone or '0890111624'
        h = h.replace(old, new_html(phone))
        state = 'แทนที่'
    else:                                  # ไม่มี -> แทรกหน้า sd-details เฉพาะคันที่มีข้อมูลจาก txt
        if phone and 'sd-details' in h:
            h = h.replace('<section class="sd-details"',
                          new_html(phone) +
                          '<section class="sd-details"', 1)
            state = 'แทรก'
        elif not phone:
            state = 'ข้าม(ไม่ทราบเซลล์)'
        else:
            state = 'ข้าม(ไม่พบจุด)'
    if h != h0 and APPLY:
        io.open(p, 'w', encoding='utf-8').write(h)
        done += 1
    rows.append((slug, state, phone or '-', h != h0))

print('%-14s %-16s %-14s %s' % ('หน้า', 'ผล', 'เบอร์เซลล์', 'เปลี่ยน'))
print('-' * 56)
for s, st, ph, ch in rows:
    print('%-14s %-16s %-14s %s' % (s, st, ph, 'ใช่' if ch else '-'))

if APPLY:
    print('\n*** เขียนทับแล้ว %d ไฟล์ ***' % done)
    bad = [p for p in sorted(glob.glob('web-updated/site/used-tractors/*/index.html'))
           if 'sd-sellercard' in io.open(p, encoding='utf-8').read()
           and 'sd-sellercard-slim' not in io.open(p, encoding='utf-8').read()]
    print('หน้าที่ยังไม่ได้ slim:', bad or 'ไม่มี ✓')
else:
    print('\n(dry-run — สั่ง --apply เพื่อบันทึก)')
