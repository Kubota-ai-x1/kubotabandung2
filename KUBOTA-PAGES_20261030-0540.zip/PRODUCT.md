# Product

<!-- impeccable:product-schema 1 -->

## Platform

web

## Stack

Next.js App Router with React, using a single-page landing experience in `app/page.js`, shared styling in `app/globals.css`, and configuration in `lib/shopConfig.js`.

## Users

Primary users are buyers and operators looking for used Kubota agricultural and construction machines, as well as genuine Kubota parts. The site is aimed at customers who need a quick way to compare categories, understand the product story, and request a price estimate without navigating a full storefront or inventory system.

Secondary audiences include local business owners, farm operators, contractors, and buyers who want a direct conversation with a Kubota supplier in Ban Dung, Udon Thani.

## Product Purpose

This product exists to help customers discover selected used tractors, harvesters, excavators, and genuine Kubota parts, then take the next step toward inquiry or purchase through a guided lead-capture flow. Success means a visitor can understand the product categories, trust the brand and local presence, and submit an estimate request or contact the team.

## Positioning

KUBOTA PARTPRO positions itself as a direct, consultative supplier of pre-owned machinery and genuine parts, with emphasis on practical fit, trusted recommendations, and local access rather than broad e-commerce browsing.

## Operating Context

The product is a marketing and lead-generation landing site rather than a full commerce platform. It is designed for desktop and mobile web traffic, with a strong hero narrative, category storytelling, trust messaging, and modal-based inquiry flows. The site assumes a locally driven sales conversation and presents the business in both Thai and English.

## Capabilities and Constraints

Confirmed capabilities:
- Multi-section landing page highlighting tractors, harvesters, excavators, and genuine parts
- Quick estimate modal with category, condition, budget, name, and phone fields
- Location modal showing a Thailand route map and local cueing for Ban Dung presence
- Brand navigation and CTA patterns for sales conversion
- Shared product metadata and contact configuration

Confirmed constraints:
- No live inventory or checkout flow is implemented
- The estimate form is a front-end demo and does not submit real data anywhere yet
- The business contact details are configurable in `lib/shopConfig.js` and currently serve as placeholders rather than a production CRM integration
- The product is a single landing experience focused on conversion and brand trust, not a multi-page catalog

## Brand Commitments

Brand name: KUBOTA PARTPRO

Established signals in the code and content:
- Industrial, dark-toned visual treatment with orange-accent KUBOTA cues
- Thai/English bilingual messaging and terminology
- Heavy emphasis on machinery, field work, and practical operational trust
- Locality and proximity messaging around KUBOTA Ban Dung

## Evidence on Hand

Real project evidence:
- `app/page.js` — the full landing page structure, modals, sections, and lead-capture behavior
- `app/globals.css` — visual system, palette, type treatments, modal styling, and responsive behavior
- `lib/shopConfig.js` — default business links, map destination, and contact metadata
- `README.md` — project description and command surface
- `package.json` — Next.js app setup and scripts

## Product Principles

1. Directly match the buyer’s real operating needs.
2. Build trust through local presence and practical guidance.
3. Convert interest with low-friction inquiry flows.
4. Keep the experience language-appropriate and commercially clear.
5. Present used equipment and parts as dependable, field-ready assets rather than commodity listings.

## Current project stage

- The current landing page is an early structural prototype derived from a standalone Markdown project, not approved final brand copy or a complete production storefront.
- Stabilize the page structure, responsive behavior, visual hierarchy, and reusable section patterns before treating the current headings or section copy as final.
- Revisit headlines, section labels, and conversion copy as a separate content phase, using verified business/product information and a professional, customer-oriented voice.
- Do not invent inventory counts, availability, service guarantees, response times, credentials, or other business claims to make copy sound more persuasive.
- Keep the design and page structure adaptable while information is incomplete; record decisions that are intentionally provisional rather than treating them as permanent requirements.

## Responsive discovery direction

- Keep the same product categories and visitor tasks available on mobile and desktop, while adapting composition to the available screen rather than shrinking one layout to fit another.
- Use a manually controlled, swipeable category carousel in the mobile hero; on desktop, show the same categories as a compact in-scene navigation list beside the shop image and introduction.
- Keep the rest of the page vertically browsable. Use gentle proximity snapping between full-screen sections rather than intercepting wheel/touch gestures or forcing exactly one section per scroll input.
- Put site search behind a magnifying-glass control in the header. The current autocomplete searches existing page sections and categories only; it is not AI search and does not claim live inventory.
- Avoid adding a duplicate tab bar or speculative promotions. Final section copy and any offers remain provisional until business details are confirmed.

## Planned sign-in and gated details

- Sign-in is a planned access step for selected deeper content or experiences, not a mandatory destination for every estimate request, product inquiry, or popup.
- Visitors may browse the landing page and preview basic information before being asked to sign in to continue to a protected detail or experience.
- The exact sign-in entry points must be chosen after the site's sections, detail views, and visitor journeys are defined; do not assume estimate submission is the sole trigger.
- The sign-in experience should feel like a smooth continuation of the KUBOTA PARTPRO site, with a branded introduction alongside the sign-in surface. Superlist is a motion/transition reference, not a pixel-copy target.
- Build the final access rules and authentication integration after the relevant content flows and account requirements are known. The design can be prototyped separately, but must not imply real authentication until it is implemented.

## Accessibility & Inclusion

The site includes basic keyboard focus styling and modal accessibility patterns (`aria-modal`, `aria-label`, focus-visible states), and it keeps the content legible through strong contrast and a clear CTA structure. Product-specific accessibility work should continue to prioritize mobile usability and inquiry clarity for low-technical, field-oriented buyers.
