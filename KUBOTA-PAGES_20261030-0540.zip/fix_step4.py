# -*- coding: utf-8 -*-
"""4) กฎราคาบนหน้ารายละเอียด (7 คัน)
   - ดาวน์ 0 บาท -> ฟรีดาวน์
   - มีราคาเงินสด -> แสดงตาม txt
   - มีแค่ดาวน์ (txt ไม่ระบุราคา) -> ช่องราคา = "ติดต่อเซลล์"
   ใช้: python fix_step4.py [--apply]"""
import io, re, sys, glob

APPLY = '--apply' in sys.argv
D = {  # slug: (ราคา, ดาวน์)
    'u6-m108s':  ('1,090,000.-', 'ฟรีดาวน์'),
    'm7040-b':   ('715,000.-',   '55,000 บาท'),
    'mu4902-b':  ('560,000.-',   'ฟรีดาวน์'),
    'l5018sp':   ('ติดต่อเซลล์', '20,000 บาท'),
    'm6240suh-b': ('655,000.-',  '35,000 บาท'),
    'mu5702-b':  ('ติดต่อเซลล์', '25,000 บาท'),
    'm7508':     ('ติดต่อเซลล์', '140,000 บาท'),
}

Q = r'\\*"'          # เครื่องหมายคำพูดหนี backslash (เข้าได้ทุกจำนวน)


def sub_both(h, value_old, value_new, label):
    """แทนค่าใน HTML และใน payload โดยผูกกับ label ให้แม่น"""
    n = 0
    # HTML
    pat_html = (r'(<span class="sd-spec-value">)' + re.escape(value_old) +
                r'(</span><span class="sd-spec-label">)' + re.escape(label) + r'(</span>)')
    h, k = re.subn(pat_html, lambda m: m.group(1) + value_new + m.group(2) + label + m.group(3), h)
    n += k
    # payload
    pat_js = (Q + r'sd-spec-value' + Q + r',' + Q + r'children' + Q + r':' + Q +
              re.escape(value_old) + Q + r'\}\],\[' + Q + r'\$' + Q + r',' + Q +
              r'span' + Q + r',null,\{' + Q + r'className' + Q + r':' + Q +
              r'sd-spec-label' + Q + r',' + Q + r'children' + Q + r':' + Q +
              re.escape(label) + Q)
    repl = (Q + 'sd-spec-value' + Q + ',' + Q + 'children' + Q + ':' + Q + value_new +
            Q + '}],[' + Q + '$' + Q + ',' + Q + 'span' + Q + ',null,{' + Q +
            'className' + Q + ':' + Q + 'sd-spec-label' + Q + ',' + Q + 'children' +
            Q + ':' + Q + label + Q)
    h, k = re.subn(pat_js, lambda m: repl, h)
    n += k
    return h, n


def sub_price(h, value_old, value_new):
    n = 0
    h, k = re.subn(r'(<strong class="sd-price-value">)' + re.escape(value_old) + r'(</strong>)',
                   lambda m: m.group(1) + value_new + m.group(2), h)
    n += k
    h, k = re.subn(Q + r'sd-price-value' + Q + r',' + Q + r'children' + Q + r':' + Q +
                   re.escape(value_old) + Q,
                   lambda m: Q + 'sd-price-value' + Q + ',' + Q + 'children' + Q + ':' +
                   Q + value_new + Q, h)
    n += k
    return h, n


print('%-13s %-4s %-16s %-16s %s' % ('หน้า', 'จุด', 'ราคา', 'ดาวน์', 'ผล'))
print('-' * 66)
for slug, (price, down) in D.items():
    p = 'web-updated/site/used-tractors/%s/index.html' % slug
    h0 = io.open(p, encoding='utf-8').read()
    h = h0
    # ราคา: จับค่าปัจจุบันก่อน
    m = re.search(r'<strong class="sd-price-value">([^<]*)</strong>', h)
    cur_p = m.group(1) if m else None
    if cur_p and cur_p != price:
        h, n = sub_price(h, cur_p, price)
    else:
        n = 0
    # ดาวน์
    m2 = re.search(r'<span class="sd-spec-value">([^<]*)</span>'
                   r'<span class="sd-spec-label">วางดาวน์</span>', h)
    cur_d = m2.group(1) if m2 else None
    k = 0
    if cur_d and cur_d != down:
        h, k = sub_both(h, cur_d, down, 'วางดาวน์')
    # ออกรถ ให้เท่ากับวางดาวน์
    m3 = re.search(r'<span class="sd-spec-value">([^<]*)</span>'
                   r'<span class="sd-spec-label">ออกรถ</span>', h)
    cur_o = m3.group(1) if m3 else None
    j = 0
    if cur_o and cur_o != down:
        h, j = sub_both(h, cur_o, down, 'ออกรถ')
    if h != h0 and APPLY:
        io.open(p, 'w', encoding='utf-8').write(h)
    print('%-13s %-4d %-16s %-16s %s' % (slug, n + k + j, price, down,
                                          'เขียน' if (h != h0 and APPLY) else
                                          ('เปลี่ยน' if h != h0 else 'ตรงแล้ว')))

print('\n*** เขียนทับแล้ว ***' if APPLY else '(dry-run — สั่ง --apply)')
