# -*- coding: utf-8 -*-
"""เช็คว่า index.html การ์ด 7-8 ถูกสคริปต์เราเขียนทับหรือเปล่า"""
import re, io, json

h = io.open('web-updated/site/index.html', encoding='utf-8').read()
arts = re.findall(r'<article class="sr-card-h".*?</article>', h, re.S)
print('การ์ดทั้งหมด:', len(arts))
for i, a in enumerate(arts, 1):
    name = re.search(r'data-name="([^"]*)"', a)
    name = name.group(1) if name else '?'
    g = re.search(r"data-gallery='(\[.*?\])'", a)
    srcs = []
    if g:
        try:
            srcs = [x['src'] for x in json.loads(g.group(1))]
        except Exception as e:
            srcs = ['JSON_ERR ' + str(e)]
    det = re.search(r'<a class="sr-detail"[^>]*href="([^"]*)"', a)
    facts = re.findall(r'<span class="k">([^<]*)</span><span class="v">([^<]*)</span>', a)
    print('\n[%d] %s' % (i, name))
    print('    detail :', det.group(1) if det else '???')
    print('    facts  :', facts if facts else '(ไม่มี)')
    print('    gallery:', len(srcs), 'รูป')
    for s in srcs[:3]:
        print('        ', s)
    if len(srcs) > 3:
        print('         ... และอีก', len(srcs) - 3)
