# -*- coding: utf-8 -*-
"""1) เบอร์โทรร้าน -> 089-011-1624 ทุกจุด
   2) ปุ่มแถบล่างสุด: แชท LINE -> เฮียเลี้ยง
   ใช้: python fix_step1.py [--apply]"""
import io, sys, re

APPLY = '--apply' in sys.argv
NEW_TEL = 'tel:0890111624'
OLD_TEL = 'tel:+66420000000'

# ทั้งโซนรถไถมือสอง (index.html + ไฟล์ payload .txt ของ Next.js) + หน้าอื่น
import glob
files = sorted(glob.glob('web-updated/site/used-tractors/*/index.html'))
files += sorted(glob.glob('web-updated/site/used-tractors/*/*.txt'))
files += ['web-updated/site/index.html',
          'web-updated/site/all-recommend/index.html',
          'web-updated/site/all-new/index.html']

print('%-52s %6s %6s %6s' % ('ไฟล์', 'เบอร์', 'ปุ่ม', 'ผล'))
print('-' * 78)
tot = [0, 0]
for p in files:
    try:
        h0 = io.open(p, encoding='utf-8').read()
    except IOError:
        print('%-52s  (ข้าม — ไม่มีไฟล์)' % p); continue
    h = h0
    a = h.count(OLD_TEL)
    h = h.replace(OLD_TEL, NEW_TEL)
    # ปุ่มแถบล่าง (มีเฉพาะ </a> ปิดทันที ไม่ใช่ "แชท LINE ทีมงาน")
    b = h.count('>แชท LINE</a>')
    h = h.replace('>แชท LINE</a>', '>เฮียเลี้ยง</a>')
    c = h.count(r'\"children\":\"แชท LINE\"')
    h = h.replace(r'\"children\":\"แชท LINE\"',
                  r'\"children\":\"เฮียเลี้ยง\"')
    tot[0] += a; tot[1] += b + c
    if h != h0:
        if APPLY:
            io.open(p, 'w', encoding='utf-8').write(h)
        print('%-52s %6d %6d %6s' % (p[-52:], a, b + c,
                                      'เขียนแล้ว' if APPLY else 'dry'))
    else:
        print('%-52s %6d %6d %6s' % (p[-52:], a, b + c, 'ไม่เปลี่ยน'))

print('-' * 78)
print('รวม เบอร์ %d จุด | ปุ่ม %d จุด' % (tot[0], tot[1]))
if not APPLY:
    print('(dry-run — สั่ง --apply เพื่อบันทึก)')
