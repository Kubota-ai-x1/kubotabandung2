# -*- coding: utf-8 -*-
"""3) แก้ RSC payload ให้ตรงกับการ์ดเซลล์แบบบาง (กัน React ลบตอน hydrate)
   ใช้: python fix_step3.py [--apply]"""
import io, re, sys, glob

APPLY = '--apply' in sys.argv
PHONE_OVERRIDE = {
    'u6-m108s': '098-2057355', 'm7040-b': '098-2057355',
    'mu4902-b': '098-2057355', 'l5018sp': '098-1039700',
    'm6240suh-b': '0610218998', 'mu5702-b': '098-8264663',
    'm7508': '0610180483', 'm8808': '098-1039700',
}


def find_node(text, start):
    """คืนช่วงของ array node ที่สมดุล จากตำแหน่ง start (ชี้ที่ '[' แรก)"""
    depth, i, instr, esc = 0, start, False, False
    while i < len(text):
        c = text[i]
        if instr:
            if esc:
                esc = False
            elif c == '\\':
                esc = True
            elif c == '"':
                instr = False
        else:
            if c == '"':
                instr = True
            elif c in '[{':
                depth += 1
            elif c in ']}':
                depth -= 1
                if depth == 0:
                    return start, i + 1
        i += 1
    return None


def build_node(phone, q):
    """q = รูปแบบหนีคำ (คัดมาจาก node เดิมในไฟล์เดียวกัน)"""
    return ('[' + q + '$' + q + ',' + q + 'section' + q + ',null,{'
            + q + 'className' + q + ':' + q + 'sd-sellercard sd-sellercard-slim' + q + ','
            + q + 'aria-label' + q + ':' + q + 'เบอร์เซลล์ประจำคัน' + q + ','
            + q + 'children' + q + ':[[[' + q + '$' + q + ',' + q + 'span' + q + ',null,{'
            + q + 'className' + q + ':' + q + 'sd-sellercard-role' + q + ','
            + q + 'children' + q + ':' + q + 'เซลล์ประจำคันนี้' + q + '}],['
            + q + '$' + q + ',' + q + 'span' + q + ',null,{'
            + q + 'className' + q + ':' + q + 'sd-sellercard-phone' + q + ','
            + q + 'children' + q + ':' + q + phone + q + '}]]]}]')


rows = []
for p in sorted(glob.glob('web-updated/site/used-tractors/*/index.html')):
    slug = p.replace('\\', '/').split('used-tractors/')[1].split('/')[0]
    h0 = io.open(p, encoding='utf-8').read()
    h = h0
    k = h.find('self.__next_f')
    if k < 0:
        rows.append((slug, 'ไม่มี payload', '-')); continue
    phone = PHONE_OVERRIDE.get(slug)
    if phone is None:
        m = re.search(r'sd-sellercard-phone[^>]*>([0-9+-]+)<', h0)
        phone = m.group(1) if m else None
    if phone is None:
        rows.append((slug, 'ข้าม(ไม่ทราบเบอร์)', '-')); continue

    pay = h[k:]
    pos = pay.find('"sd-sellercard')
    if pos < 0:
        rows.append((slug, 'payload ไม่มีการ์ด', phone)); continue

    # หาจุดเริ่ม array ของ node นี้ (ย้อนกลับไปหา '[' ก่อน 'section')
    s = pay.rfind('[', 0, pos)
    while s > 0:
        if pay[s] == '[' and pay[s:s + 60].find('section') >= 0:
            break
        s = pay.rfind('[', 0, s)
    span = find_node(pay, s)
    if not span:
        rows.append((slug, 'หา node ไม่จบ', phone)); continue

    # จับรูปแบบหนีคำจาก node เดิม
    m = re.search(r'\\*"section\\*"', pay[s:s + 40])
    q = m.group(0).replace('section', '') if m else '\\"'
    new = build_node(phone, q)
    pay = pay[:s] + new + pay[span[1]:]
    h = h[:k] + pay
    if h != h0 and APPLY:
        io.open(p, 'w', encoding='utf-8').write(h)
    rows.append((slug, 'แทนที่ payload' if h != h0 else 'ไม่เปลี่ยน', phone))

print('%-14s %-24s %s' % ('หน้า', 'ผล payload', 'เบอร์'))
print('-' * 52)
for a, b, c in rows:
    print('%-14s %-24s %s' % (a, b, c))
print()
print('*** เขียนทับแล้ว ***' if APPLY else '(dry-run — สั่ง --apply)')
